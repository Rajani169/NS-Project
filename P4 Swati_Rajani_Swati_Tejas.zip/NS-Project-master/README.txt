Using Flask for Encrypting Plaintext stored in a file and storing the cipher text in another file. Then, using Cryptanalysis, the cipher text is analysed to deduce plaintext and key.

Requirement : 
python version = 3.8.10
Flask version = 2.2.3
Werkzeug 2.2.3

code to run : flask --app Encryption run


