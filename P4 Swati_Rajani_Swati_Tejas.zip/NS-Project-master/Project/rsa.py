import random
import sys


def extendedGCD(a: int, b: int) -> (int, int):
    if b:
        u, v = extendedGCD(b, a % b)
        return v, u - v * (a // b)

    return 1, 0


def calculatePrivateKey(e: int, p: int, q: int) -> int:
    u, _ = extendedGCD(e, (p - 1) * (q - 1))
    return u


def randomBitsGenerator(bit_length: int) -> int:
    return random.getrandbits(bit_length)


def separatePowersOfTwo(n: int) -> (int, int):
    r = 0
    d = n

    while d > 0 and d % 2 == 0:
        d = d // 2
        r += 1

    return r, d


def millerRabinPrimalityTest(n: int, k: int) -> bool:
    r, d = separatePowersOfTwo(n - 1)

    for i in range(k):
        a = randomBitsGenerator(n.bit_length())
        while a not in range(2, n - 2 + 1):
            a = randomBitsGenerator(n.bit_length())
        x = pow(a, d, n)
        # print(a)
        # print(d)
        # print(n)
        # print(x)
        if x == 1 or x == n - 1:
            continue
        prime_found = False
        for j in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                prime_found = True
                break

        if not prime_found:
            return False

    return True


def primeGenerator(bit_length: int) -> int:
    range_lower_limit = pow(2, bit_length - 1)
    range_upper_limit = pow(2, bit_length) - 1

    while True:
        sampled_prime = randomBitsGenerator(bit_length)
        while sampled_prime not in range(range_lower_limit, range_upper_limit + 1) or (sampled_prime % 2 == 0):
            sampled_prime = randomBitsGenerator(bit_length)

        k = 64
        if millerRabinPrimalityTest(sampled_prime, k):
            return sampled_prime


def encrypt(plaintext: bytes, e: int, n: int) -> int:
    pt_converted = int.from_bytes(plaintext, "big")
    return pow(pt_converted, e, n)


def decrypt(ciphertext: int, d: int, n: int) -> bytes:
    pt_converted = pow(ciphertext, d, n)
    return pt_converted.to_bytes((pt_converted.bit_length() + 7) // 8, "big")


if __name__ == "__main__":
    key_size = 1024
    prime_number_bit_length = key_size // 2

    # generating primes
    p = primeGenerator(prime_number_bit_length)
    q = primeGenerator(prime_number_bit_length)

    # public key
    n = p * q
    # standard value of 'e' assumed
    e = 65537

    # private key
    d = calculatePrivateKey(e, p, q)

    # encryption
    with open(r'D:\Downloads\NS-Project-master\NS-Project-master\Project\input.txt') as f:
        plaintext = f.readlines()
    print(plaintext)
    pt_in_bytes = bytes(plaintext[0], 'utf-8')
    # encrypting the plaintext using public key (e, n)
    ciphertext = encrypt(pt_in_bytes, e, n)
    # print(ciphertext)

    # decryption using private key (d, n)
    recovered_pt = decrypt(ciphertext, d, n)

    with open(r'D:\Downloads\NS-Project-master\NS-Project-master\Project\output.txt', 'w') as f:
        sys.stdout = f
        print("Plaintext sent: ", plaintext[0])
        print('cipher text', ciphertext.decode())
        print("Plaintext recovered: ", recovered_pt.decode())

        if recovered_pt == pt_in_bytes:
            print("Algo Working")
        else:
            print("Not Working")
