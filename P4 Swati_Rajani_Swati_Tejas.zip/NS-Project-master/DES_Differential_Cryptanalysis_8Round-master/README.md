Just Run the p1.py file using python3 p1.py to get both 48 and 56 bit keys. It may take upto 5-8 minutes to find the 48 and 56 bit keys.
