
from flask import Flask, render_template, request
app = Flask(__name__)
app.debug = True
from math import ceil
 

@app.route("/vigenere", methods=["POST", "GET"])
def vigenere():
    if request.method== "GET":
        return render_template('vigenere.html')
    else:
        plaintext = request.files['pt']
        ct = request.files['ct']
        pt_array = []
        ct_array = []
        with open(plaintext.filename, 'r') as f:
            
            lines = f.readlines()
        pt_array = [line.strip() for line in lines]
        
        with open(ct.filename, 'r') as f:
            lines = f.readlines()
            ct_array = [line.strip() for line in lines]
        ct_array = ct_array[1:]
        # print(pt_array,ct_array)

        key_array = []
        for i in range(len(pt_array)):
            print(i)
            pt = pt_array[i]
            pt=pt.replace(" ","")
            ct = ct_array[i]
            ct=ct.replace(" ","")
            pt = pt.lower()
            ct = ct.lower()
            key=''
            for i in range(len(pt)):
                x = ord(pt[i])-97
                y = ord(ct[i])-97
                res = (y-x+26)%26
                key+=chr(res+97)
            key_array.append(key)
        return render_template('show_decryption.html', data = {'key': key_array, 'pt': pt_array, 'ct': ct_array,'algo':'vigenere'})       
                
@app.route("/RSA", methods=["POST", "GET"])
def RSA():
    if request.method == "GET":
        return render_template('RSA_decrypt.html')
    else:
    
        ciphertext = request.files['ct']
        N = request.files['N']
        
        ct_array = []
        with open(ciphertext.filename, 'r') as f:
            lines = f.readlines()
        ct_array = [line.strip() for line in lines]
        ct_array = ct_array[1:]
        with open(N.filename, 'r') as f:
            lines = f.readlines()
            N = [int(line.strip()) for line in lines]
        print(ct_array)
        x = BroadcastAttack(17,N,ct_array)
        msg = x.attack()
        return render_template('RSA_show.html', msg=msg)

        
      

class BroadcastAttack:
    t = []
    message = 0

    '''
    Takes in public key, an array of moduli, an array of ciphertexts
    '''

    def __init__(self, e, N, C):
        self.e = e
        self.N = N
        self.C = C
        print(len(self.N),len(self.C))

    def calculate_partials(self):
        for i in range(self.e):
            mod_product = 1
            for j in range(self.e):
                if i != j:
                    mod_product *= self.N[j]
            # print("hey")
            # print(mod_product*2)
            # print(str(self.C[i] * mod_product))
            print(self.C[i])
            print(mod_product)
            print(self.N[i])
            print(ModUtil.modinv(mod_product, self.N[i]))
            t_i = self.C[i] * mod_product * ModUtil.modinv(mod_product, self.N[i])
            print(t_i)
            self.t.append(t_i)

    def solve_congruence(self):
        partial_total = 0
        mod_product = 1
        for i in range(self.e):
            partial_total += self.t[i]
            mod_product *= self.N[i]

        self.message = ModUtil.isqrt(partial_total % mod_product, self.e)

    def attack(self):
        self.calculate_partials()
        self.solve_congruence()
        return self.message


class ModUtil:
    '''
    Solves x, y for equation: ax + by = gcd(a, b)
    Return gcd, x, y
    '''

    @staticmethod
    def egcd(a, b):
        if a == 0:
            return (b, 0, 1)
        else:
            gcd, x_old, y_old = ModUtil.egcd(b % a, a)
            return (gcd, y_old - (b // a) * x_old, x_old)

    '''
    Finds modinv of a in mod m
    '''

    @staticmethod
    def modinv(a, m):
        gcd, x, y = ModUtil.egcd(a, m)
        if gcd != 1:
            raise Exception('Mod Inv Undefined')
        else:
            return x % m

    '''
    Newton's method of finding integer square roots
    '''

    @staticmethod
    def isqrt(n, k):
        u, s = n, n + 1
        while u < s:
            s = u
            t = (k - 1) * s + n // pow(s, k - 1)
            u = t // k
        return s


@app.route("/pf", methods=["POST", "GET"])
def pf():
    from playfair_main import main_helper
    with open(r"D:\Downloads\NS-Project-master\NS-Project-master\cipher_file.txt", "r") as text:
        ciphertext = "".join(text.readlines())
        max_score = float("-inf")
        i = 0
        default_key = main_helper.DEFAULT_KEY
        while True:
            i += 1
            score, key, default_key = main_helper.simulated_annealing(ciphertext, default_key)
            if score > max_score:
                max_score = score
                main_helper.playfair.set_key(key)
                print(f"best score {max_score}")
                print(f"key: {key}")
                print(f"message: {main_helper.playfair.decrypt(ciphertext)}")



    
    
    